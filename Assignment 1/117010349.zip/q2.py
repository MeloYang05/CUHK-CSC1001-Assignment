a=input('Enter a integer:')
for i in a:
    print(i)