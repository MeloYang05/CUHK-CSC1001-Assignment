n=0
a=int(input('please enter an integer:'))
while n**2<=a:
    n=n+1
print('the smallest ingeter is:',n)